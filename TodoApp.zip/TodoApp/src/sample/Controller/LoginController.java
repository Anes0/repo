package sample.Controller;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import sample.Animation.Shaker;
import sample.DataBase.Const;
import sample.DataBase.DataBaseHandler;
import sample.Model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

        private int userID;
        @FXML
        private JFXTextField loginUsername;

        @FXML
        private JFXPasswordField loginPassword;

        @FXML
        private JFXButton loginB;

        @FXML
        private JFXButton loginSignUpB;

        private DataBaseHandler dataBaseHandler;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loginSignUpB.setOnAction(actionEvent -> {
            loginSignUpB.getScene().getWindow().hide();
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/sample/View/SignUp.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root=loader.getRoot();
            Stage stage=new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();

        });

        loginB.setOnAction(actionEvent -> {
            String loginText=loginUsername.getText().trim();
            String loginPwd=loginPassword.getText().trim();
            dataBaseHandler = new DataBaseHandler();

            User user=new User();
            user.setUsername(loginText);
            user.setPassword(loginPwd);



            ResultSet userRow=dataBaseHandler.getUser(user);
            int counter=0;
            try {
                while (userRow.next()){
                    counter++;
                    System.out.println(userRow.getString("firstname"));//C'est juste pour afficher le firstname, C'est en plus , Ce n'est pas necissaire
                    userID=userRow.getInt("userid");//Pour avoir la clé primaire et l'utiliser ds Task comme clé étrangère
                }
                if (counter == 1){
                    showItemScreen();
                    System.out.println("Login Successful");
                }else {
                    Shaker UserNameShaker=new Shaker(loginUsername);
                    Shaker PassWordShaker=new Shaker(loginPassword);
                    UserNameShaker.shake();
                    PassWordShaker.shake();
                }
            }catch (SQLException e){
                e.printStackTrace();
            }
            showItemScreen();
        });
    }

    private void loginUser(String username,String password) {

    }

    private void showItemScreen(){

        loginB.getScene().getWindow().hide();
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/sample/View/AddItem.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root=loader.getRoot();
        Stage stage=new Stage();
        stage.setScene(new Scene(root));
        AddItemController addItemController=loader.getController();
        addItemController.setUserID(userID);


        stage.showAndWait();

    }
}

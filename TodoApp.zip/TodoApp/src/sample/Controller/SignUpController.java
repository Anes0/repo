package sample.Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import sample.DataBase.DataBaseHandler;
import sample.Model.User;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class SignUpController implements Initializable {


        @FXML
        private JFXTextField signupfirsname;

        @FXML
        private JFXTextField signuplastname;

        @FXML
        private JFXTextField signupusername;

        @FXML
        private JFXTextField signuplocation;

        @FXML
        private JFXCheckBox signupcheckboxmale;

        @FXML
        private JFXCheckBox signupcheckboxfemale;

        @FXML
        private JFXPasswordField signuppassword;

        @FXML
        private JFXButton signB;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            signB.setOnAction(actionEvent -> {
                createUser();
            });
    }

        private void createUser() {
                DataBaseHandler dataBaseHandler=new DataBaseHandler();
                String g="";
                if (signupcheckboxmale.isSelected()){
                        g="Male";
                }else {
                        if (signupcheckboxfemale.isSelected()){
                                g="Female";
                        }
                }
                User user=new User(signupfirsname.getText(),signuplastname.getText(),signupusername.getText(),signuppassword.getText(),
                        signuplocation.getText(),g);
                try {
                        dataBaseHandler.signUpUser(user);
                } catch (SQLException e) {
                        e.printStackTrace();
                }
                signupfirsname.setText("");
                signuplastname.setText("");
                signupusername.setText("");
                signuppassword.setText("");
                signuplocation.setText("");

        }

}

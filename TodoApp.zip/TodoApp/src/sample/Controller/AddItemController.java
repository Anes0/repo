package sample.Controller;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import sample.Animation.Shaker;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddItemController implements Initializable {

    protected static int userID;
    @FXML
        private ImageView addB;

        @FXML
        private Label addItemLabel;


        @FXML
        private AnchorPane rootPane;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addB.addEventHandler(MouseEvent.MOUSE_CLICKED, mouseEvent -> {
            Shaker shaker=new Shaker(addB);
            shaker.shake();

            FadeTransition fadeTransition=new FadeTransition(Duration.millis(2000),addB);//2000 hiya la durée li tab9a takhdam had le fadetransation,
            // wel parametre 2eme howa 3liman ntab9ouha

            addB.relocate(20,125);//Modifier La localisation
            addItemLabel.setOpacity(0);//Modifier La visibilité

            fadeTransition.setFromValue(1f);//La visibilité li tabda biha kima hna tabda kima kanat
            fadeTransition.setToValue(0f);//La visibilité li twali fiha kima hna trou7 kamal
            fadeTransition.setCycleCount(4);//ch7al man khatra t3awad
            fadeTransition.setAutoReverse(false);//twali l plasatha wala lala
            fadeTransition.play();

            try {
                AnchorPane formPane= FXMLLoader.load(getClass().getResource("/sample/View/AddItemForm.fxml"));

                AddItemController.userID=getUserID();

//                AddItemFormController addItemController=new AddItemFormController();
//                addItemController.setUserID(this.userID);

                rootPane.getChildren().setAll(formPane);
                FadeTransition fadeTransition1=new FadeTransition(Duration.millis(2500),formPane);
                fadeTransition1.setFromValue(0f);
                fadeTransition1.setToValue(1f);
                fadeTransition1.setCycleCount(1);
                fadeTransition1.setAutoReverse(false);
                fadeTransition1.play();

            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

    public void setUserID(int userID){
        this.userID=userID;
        System.out.println("User ID "+this.userID);
    }

    public int getUserID() {
        return userID;
    }
}

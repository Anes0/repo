package sample.Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import sample.DataBase.DataBaseHandler;
import sample.Model.Task;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class ListController implements Initializable {

    @FXML
    private Label successLabel;

    @FXML
    private JFXButton todoB;

    @FXML
    private JFXListView<Task> list;

    @FXML
    private JFXTextField listTask;

    @FXML
    private JFXTextField listDescription;

    @FXML
    private JFXButton listB;

    private ObservableList <Task>tasks;

    private DataBaseHandler dataBaseHandler;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        dataBaseHandler=new DataBaseHandler();
        ResultSet resultSet=dataBaseHandler.getTaskByUser(AddItemController.userID);
        try {
            tasks=FXCollections.observableArrayList();
            while (resultSet.next()){
                System.out.println("User Tasks: " +resultSet.getString("taskid"));
                Task task=new Task();
                task.setTask(resultSet.getString("task"));
                task.setDatecreated(resultSet.getTimestamp("datecreated"));
                task.setDescription(resultSet.getString("description"));
                tasks.add(task);
                System.out.println("Tasks "+resultSet.getString("task"));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }

        list=new JFXListView<>();
        //System.out.println(dataBaseHandler.getTaskByUser(1));
        list.setItems(tasks);
        list.setCellFactory(CellController->new CellController());

    }
}









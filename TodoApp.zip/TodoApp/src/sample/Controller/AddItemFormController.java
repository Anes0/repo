package sample.Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import sample.DataBase.DataBaseHandler;
import sample.Model.Task;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.ResourceBundle;

public class AddItemFormController extends AddItemController implements Initializable {

        private int userId;
        private DataBaseHandler dataBaseHandler;

        @FXML
        private JFXTextField addItemFormTask;

        @FXML
        private JFXTextField addItemFormDescription;

        @FXML
        private JFXButton addItemFormB;


        @FXML
        private Label successLabel;

        @FXML
        private JFXButton todoB;

        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
                dataBaseHandler=new DataBaseHandler();
                addItemFormB.setOnAction(actionEvent -> {
                        Task task=new Task();
                        Calendar calendar=Calendar.getInstance();
                        java.sql.Timestamp timestamp=new java.sql.Timestamp(calendar.getTimeInMillis());
                        String tasktext=addItemFormTask.getText().trim();
                        String taskdesc=addItemFormDescription.getText().trim();
                        if (!tasktext.equals("")||!taskdesc.equals("")){
                                //System.out.println("UserId Add  "+AddItemController.userID);
                                task.setUserID(AddItemController.userID);
                                task.setDatecreated(timestamp);
                                task.setDescription(taskdesc);
                                task.setTask(tasktext);
                                dataBaseHandler.addTask(task);

                                successLabel.setVisible(true);
                                todoB.setVisible(true);
                                DataBaseHandler dataBaseHandler=new DataBaseHandler();
                                int tasknum= 0;
                                try {
                                        tasknum = dataBaseHandler.getAllTask(AddItemController.userID);
                                } catch (SQLException e) {
                                        e.printStackTrace();
                                } catch (ClassNotFoundException e) {
                                        e.printStackTrace();
                                }
                                todoB.setText("My 2Do's "+tasknum);
                                addItemFormTask.setText("");
                                addItemFormDescription.setText("");
                                System.out.println("Task Added, UserID "+AddItemController.userID);
                        }else {
                                System.out.println("Error add Task");
                        }



                        todoB.setOnAction(actionEvent1 -> {
                                FXMLLoader fxmlLoader=new FXMLLoader();
                                try {
                                        fxmlLoader.setLocation(getClass().getResource("/sample/View/List.fxml"));
                                        fxmlLoader.load();
                                } catch (IOException e) {
                                        e.printStackTrace();
                                }
                                Parent parent=fxmlLoader.getRoot();
                                Stage stage=new Stage();
                                stage.setScene(new Scene(parent));
                                stage.showAndWait();
                        });

                });

        }

        public int getUserID() {
                return userId;
        }
        public void setUserID(int userId) {
                this.userId= userId;
                System.out.println("userID AddItemForm "+userID);
        }
}

package sample.Controller;

import com.jfoenix.controls.JFXListCell;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;
import sample.Model.Task;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class CellController extends JFXListCell<Task> implements Initializable{
    @FXML
    private AnchorPane rootPane;

    @FXML
    private ImageView iconImageView;

    @FXML
    private Label taskLabel;

    @FXML
    private Label descriptionLabel;

    @FXML
    private Label datecreatedLabel;

    @FXML
    private ImageView deleteB;

    private FXMLLoader fxmlLoader;


    @Override
    public void updateItem(Task item,boolean empty){
        super.updateItem(item,empty);
        if (empty||item==null){
            setText(null);
            setGraphic(null);
        }else {
            if (fxmlLoader==null){
                fxmlLoader=new FXMLLoader(getClass().getResource("/sample/View/Cell.fxml"));
                fxmlLoader.setController(this);
                try {
                    fxmlLoader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                taskLabel.setText(item.getTask());
                datecreatedLabel.setText(item.getDatecreated().toString());
                descriptionLabel.setText(item.getDescription());

                setText(null);
                setGraphic(rootPane);
            }

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


    }


}

package sample.Animation;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class Shaker {
    private TranslateTransition translateTransition;

    public Shaker(Node node) {
        translateTransition=new TranslateTransition(Duration.millis(50),node);
        translateTransition.setFromX(0f);//Decaler de l'axe des X
        translateTransition.setByX(10f);//N'execute plus sans le setFromX
        translateTransition.setFromY(0f);
        translateTransition.setByY(10f);
        translateTransition.setFromZ(0f);
        translateTransition.setByZ(10f);
        translateTransition.setCycleCount(2);//Nombre e répétitions
        translateTransition.setAutoReverse(true);//Revenir à sa place ou pas
    }

    public void shake(){
        translateTransition.playFromStart();
    }
}

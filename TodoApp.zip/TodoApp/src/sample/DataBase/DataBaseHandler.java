package sample.DataBase;

import sample.Controller.AddItemController;
import sample.Controller.AddItemFormController;
import sample.Controller.LoginController;
import sample.Model.Task;
import sample.Model.User;

import java.sql.*;

public class DataBaseHandler extends Configs {
    Connection dbconnection;
    public Connection getDbconnection() throws ClassNotFoundException, SQLException {
        String connectionString="jdbc:mysql://localhost:3306/todoapp?useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        Class.forName("com.mysql.jdbc.Driver");
        dbconnection= DriverManager.getConnection(connectionString,"root","anes ha 0666");

        return dbconnection;
    }

     public void signUpUser(User user) throws SQLException {

        String insert="INSERT INTO "+Const.USERS_TABLE+"("+Const.USERS_FIRSTNAME+","+Const.USERS_LASTNAME+","+Const.USERS_USERNAME+","+Const.USERS_PASSWORD+","
                +Const.USERS_LOCATION+","+Const.USERS_GENDER+")"+"VALUES (?,?,?,?,?,?)";
         try (PreparedStatement preparedStatement = getDbconnection().prepareStatement(insert)) {
             preparedStatement.setString(1, user.getFirstname());
             preparedStatement.setString(2, user.getLastname());
             preparedStatement.setString(3, user.getUsername());
             preparedStatement.setString(4, user.getPassword());
             preparedStatement.setString(5, user.getLocation());
             preparedStatement.setString(6, user.getGender());
             preparedStatement.executeUpdate();
         } catch (ClassNotFoundException e) {
             e.printStackTrace();
         }
     }

     public ResultSet getUser(User user){
        ResultSet resultSet=null;
        if ((!user.getUsername().equals(""))||!user.getPassword().equals("")){
            String query="SELECT * FROM "+ Const.USERS_TABLE + " WHERE "+Const.USERS_USERNAME +"=?"+ " AND "+ Const.USERS_PASSWORD+"=?";
            try {
                PreparedStatement preparedStatement = getDbconnection().prepareStatement(query);
                preparedStatement.setString(1,user.getUsername());
                preparedStatement.setString(2,user.getPassword());
                resultSet=preparedStatement.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }else {
            System.out.println("Error GET_ USER");
        }
        return resultSet;
     }

        public void addTask(Task task){

            String insert="INSERT INTO "+Const.TASKS_TABLE+" ("+Const.USERS_ID+","+Const.TASKS_TASK+","+Const.TASKS_DATECREATED+","
                    +Const.TASKS_DESCRIPTION+")"+"VALUES (?,?,?,?)";
            try {PreparedStatement preparedStatement = getDbconnection().prepareStatement(insert);
                preparedStatement.setInt(1,task.getUserID());
                preparedStatement.setString(2, task.getTask());
                preparedStatement.setTimestamp(3, task.getDatecreated());
                preparedStatement.setString(4, task.getDescription());
                preparedStatement.executeUpdate();
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }

        public int getAllTask(int userId) throws SQLException,ClassNotFoundException{
            String query="SELECT COUNT(*) FROM "+Const.TASKS_TABLE+" WHERE "+Const.USERS_ID+" = ?";

                PreparedStatement preparedStatement = getDbconnection().prepareStatement(query);
                preparedStatement.setInt(1, userId);
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    return resultSet.getInt(1);//1 est la colonne qui va avoir ce résultat
                }
            return resultSet.getInt(1);
        }

        public ResultSet getTaskByUser(int userID){
            ResultSet resultSet=null;
            String query="SELECT * FROM "+Const.TASKS_TABLE+" WHERE "+Const.USERS_ID+" = ?";
            try{
                PreparedStatement preparedStatement = getDbconnection().prepareStatement(query);
                preparedStatement.setInt(1,userID);
                resultSet=preparedStatement.executeQuery();
                while (resultSet.next()){
                    resultSet.getString("task");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return resultSet;
        }

}

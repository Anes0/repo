package sample.DataBase;

public class Configs {
    protected String dbUser="root";
    protected String dbPass="anes ha 0666";

}
